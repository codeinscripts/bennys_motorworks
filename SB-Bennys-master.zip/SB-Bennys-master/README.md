
# Installation

1. Download 
2. Add "ensure SB-Bennys" to your server.cfg
3. Start Server 


# Any Issues Or Help 

https://discord.gg/jC9YgyK
